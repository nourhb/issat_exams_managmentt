<?php
// Retrieve student ID, subject ID, and note from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $matiere = $_POST['matiere'];
    $note = $_POST['note'];

    // Connect to MySQL database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "myissat";

    // Create a new connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert note (mark) for the student related to the subject
    $insert_sql = "INSERT INTO note (student_id, etudiant_id, note, matiere) VALUES (?, ?, ?, ?)";

    // Prepare and execute the statement
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("iiid", $student_id, $etudiant_id, $note, $matiere);
    if ($stmt->execute()) {
        echo "Note added successfully for Student ID: $id, Subject ID: $matiere";
    } else {
        echo "Error adding note: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
